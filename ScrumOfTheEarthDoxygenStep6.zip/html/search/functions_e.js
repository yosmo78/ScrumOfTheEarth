var searchData=
[
  ['text',['Text',['../classText.html#a2af2490841998a368bccb3eaed6d3698',1,'Text']]]
];
