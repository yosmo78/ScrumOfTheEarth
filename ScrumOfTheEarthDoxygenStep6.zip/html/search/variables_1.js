var searchData=
[
  ['a',['a',['../shape__input__file__specs_8txt.html#ae28cf074afc52317b2105a81fa268a8c',1,'shape_input_file_specs.txt']]],
  ['alignbottom',['AlignBottom',['../shape__input__file__specs_8txt.html#af05cf9503398beaab2d0f1cde0af87ff',1,'shape_input_file_specs.txt']]],
  ['alignright',['AlignRight',['../shape__input__file__specs_8txt.html#aafd721ba2c64294fd06ac546c7addf5e',1,'shape_input_file_specs.txt']]],
  ['aligntop',['AlignTop',['../shape__input__file__specs_8txt.html#aee1cc7fcf53eb2309c193209ca375621',1,'shape_input_file_specs.txt']]]
];
