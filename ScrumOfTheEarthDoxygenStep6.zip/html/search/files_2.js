var searchData=
[
  ['delete_5fzeros_2ecpp',['delete_zeros.cpp',['../delete__zeros_8cpp.html',1,'']]],
  ['delete_5fzeros_2eh',['delete_zeros.h',['../delete__zeros_8h.html',1,'']]],
  ['doxygen_5flog_2etxt',['doxygen_log.txt',['../doxygen__log_8txt.html',1,'']]]
];
