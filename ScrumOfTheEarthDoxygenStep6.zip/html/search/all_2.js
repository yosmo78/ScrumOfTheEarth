var searchData=
[
  ['begin',['begin',['../classmyStd_1_1vector.html#adaa284b6b387f70d3244b4d6e64869c3',1,'myStd::vector::begin()'],['../classmyStd_1_1vector.html#a71600f2a06ab5c279a469972d713d5d6',1,'myStd::vector::begin() const ']]],
  ['beveljoin',['BevelJoin',['../shape__input__file__specs_8txt.html#a5375660f38f399a9c1c854c3579fdce5',1,'shape_input_file_specs.txt']]],
  ['black',['black',['../shape__input__file__specs_8txt.html#a54a8afc7fef4e6a72193d1b76188b473',1,'shape_input_file_specs.txt']]],
  ['blue',['blue',['../shape__input__file__specs_8txt.html#a502b3afd7545a4195802c325ab686a9f',1,'shape_input_file_specs.txt']]],
  ['brushcolor',['BrushColor',['../shape__input__file__specs_8txt.html#a354fc5430ab296aed56472b5bd70b09e',1,'shape_input_file_specs.txt']]],
  ['brushstyle',['BrushStyle',['../shape__input__file__specs_8txt.html#ad07f6fe6c28dcb0b3bdc324a72d0051f',1,'shape_input_file_specs.txt']]]
];
