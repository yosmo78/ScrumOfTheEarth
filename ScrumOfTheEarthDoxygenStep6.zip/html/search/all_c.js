var searchData=
[
  ['normal',['Normal',['../shape__input__file__specs_8txt.html#a0c0bd83f93fb282ea2b33e44c2f3cc34',1,'shape_input_file_specs.txt']]]
];
