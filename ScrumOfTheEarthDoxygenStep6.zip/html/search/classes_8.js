var searchData=
[
  ['text',['Text',['../classText.html',1,'']]]
];
