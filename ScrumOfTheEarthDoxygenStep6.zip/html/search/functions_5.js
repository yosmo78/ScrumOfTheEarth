var searchData=
[
  ['fill_5ftable',['fill_table',['../pop__table_8cpp.html#a7e4b678b55853077d6514112c661d121',1,'fill_table(QTableWidget *tble, myStd::vector&lt; Shape * &gt; vec):&#160;pop_table.cpp'],['../pop__table_8h.html#a6f42cb3c5185e6fdaf9c12c620c5b87f',1,'fill_table(QTableWidget *, myStd::vector&lt; Shape * &gt;):&#160;pop_table.cpp']]],
  ['findshape',['findShape',['../searchandcompare_8cpp.html#ae156afea82af96484e6d6f00195737aa',1,'findShape(myStd::vector&lt; Shape * &gt; vec, unsigned int id):&#160;searchandcompare.cpp'],['../searchandcompare_8h.html#a4eb63ab42e0f441cc4158b619f33cd55',1,'findShape(myStd::vector&lt; Shape * &gt;, unsigned int):&#160;searchandcompare.cpp']]]
];
