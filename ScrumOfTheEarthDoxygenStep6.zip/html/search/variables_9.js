var searchData=
[
  ['magenta',['magenta',['../shape__input__file__specs_8txt.html#a31668012af4e119081d3a9775a7e89b3',1,'shape_input_file_specs.txt']]]
];
