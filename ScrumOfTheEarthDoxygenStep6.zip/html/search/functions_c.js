var searchData=
[
  ['rectangle',['Rectangle',['../classRectangle.html#a1dca3e66dc1317df74dda6c1984728ff',1,'Rectangle']]],
  ['renderarea',['RenderArea',['../classRenderArea.html#a71baad4c7f205d8f3c7fa2b1c7483448',1,'RenderArea']]],
  ['reserve',['reserve',['../classmyStd_1_1vector.html#a50e786a02a59e689999365037ae26b3a',1,'myStd::vector']]],
  ['resize',['resize',['../classmyStd_1_1vector.html#aa54bd9c3d8d3b6191d7eb7f85490eadb',1,'myStd::vector']]]
];
