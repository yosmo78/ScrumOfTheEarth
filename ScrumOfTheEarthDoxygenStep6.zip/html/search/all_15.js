var searchData=
[
  ['x1',['x1',['../shape__input__file__specs_8txt.html#a2c75107475dd4c72dd2083af2e04d090',1,'shape_input_file_specs.txt']]],
  ['x2',['x2',['../shape__input__file__specs_8txt.html#a9f1fa2fb07ac3e1d8394274cb160df5c',1,'shape_input_file_specs.txt']]],
  ['x3',['x3',['../shape__input__file__specs_8txt.html#a5d57507e254e2593e5a0a6a08c551eed',1,'shape_input_file_specs.txt']]],
  ['xn',['xN',['../shape__input__file__specs_8txt.html#a7c48dc90493b459f75b4b7583faca250',1,'shape_input_file_specs.txt']]]
];
