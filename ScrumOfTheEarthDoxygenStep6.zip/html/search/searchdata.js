var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxy~",
  1: "acelmprstvw",
  2: "mu",
  3: "acdeglmprstvw",
  4: "abcdefgilmoprstuvw~",
  5: "_abcdeghlmnprstvxy",
  6: "ci"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs"
};

