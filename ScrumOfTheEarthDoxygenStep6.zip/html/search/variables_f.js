var searchData=
[
  ['verpattern',['VerPattern',['../shape__input__file__specs_8txt.html#abe8b0fed5e2471bcf0087a518498641a',1,'shape_input_file_specs.txt']]]
];
