var searchData=
[
  ['getstrings_2ecpp',['getstrings.cpp',['../getstrings_8cpp.html',1,'']]],
  ['getstrings_2eh',['getstrings.h',['../getstrings_8h.html',1,'']]]
];
