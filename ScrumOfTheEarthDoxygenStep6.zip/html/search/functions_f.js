var searchData=
[
  ['update_5fwin',['update_win',['../classMoveShape.html#a020f54b76f345cc9fa83ba8deb4af9c6',1,'MoveShape']]],
  ['update_5fwindow',['update_Window',['../classAddShape.html#a6f79ea980ff8d6e7001c0b9b48d5ddb4',1,'AddShape::update_Window()'],['../classMainWindow.html#a59351bdf1235b640a416121e7b8d89d3',1,'MainWindow::update_window()']]]
];
