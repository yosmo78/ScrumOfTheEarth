var searchData=
[
  ['helvetica',['Helvetica',['../shape__input__file__specs_8txt.html#a29385f48845f4580b6fa961e5dfbc5d1',1,'shape_input_file_specs.txt']]],
  ['horpattern',['HorPattern',['../shape__input__file__specs_8txt.html#a97b62d570251a80c34bc3055dab54ac6',1,'shape_input_file_specs.txt']]]
];
