var searchData=
[
  ['l',['l',['../shape__input__file__specs_8txt.html#a2e02238fe11bc76d2a69c565c7391545',1,'shape_input_file_specs.txt']]],
  ['light',['Light',['../shape__input__file__specs_8txt.html#a8326866c3d37167e950130bbd95d25ec',1,'shape_input_file_specs.txt']]]
];
