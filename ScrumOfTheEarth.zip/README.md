# ScrumOfTheEarth
All steps for the deliverables are at this level with the name step at the end of its name
1) GitHub URLStep1.txt
2) ScrumOfTheEarthStep2.zip
3) ScrumOfTheEarthStep3.zip
4) FillingRequirementsStep4.txt
5) ScrumArtifactsStep5.txt
6) ScrumOfTheEarthDoxygenStep6.zip
7) valgrindVectorstep7.png vectorDriver.cpp
8) Project_Team_ContributionsStep8.pdf

EC) searchandcompare.h
EC2) waffle.io(EC).png

Alrighty here, gather 'round... Let me tell you a little story. This story yet; is no simple story, but one of a 2D modeler. A 2D modeler that could but shouldn't, that did but wouldn't. That 2D modeler was by the strongest band of adventurers known throughout the land... And that group was simply the Scum of the Earth

All of the UML diagrams were written with draw.io and are in xml format
